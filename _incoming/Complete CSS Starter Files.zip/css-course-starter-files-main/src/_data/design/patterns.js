const CodeSample = require('../../lib/code-sample.js');

module.exports = new CodeSample(
  '/pattern-library/patterns',
  '/pattern-library/pattern',
  '/pattern-library/pattern-preview'
);
