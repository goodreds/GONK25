The layout is controlled by [`flow`](/pattern-library/css-compositions/#flow) and [`cluster`](/pattern-library/css-compositions/#cluster). The variants in this pattern library only change that layout system. 

By design, the nav will `inherit` font size, so it's imperative you account for that in your page context, either with utility classes or context specific CSS.