Some really important factors about this pattern are the following: 
1. The heading is visually hidden 
2. This heading should be broken on to two lines, which are in turn, distributed by CSS grid 
3. Try to keep the heading short and snappy 
4. Make sure the image fits nicely in a 16/9 aspect ratio