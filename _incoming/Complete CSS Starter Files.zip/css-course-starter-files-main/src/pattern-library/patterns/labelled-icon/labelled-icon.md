This block is mainly structural because the visuals will be controlled by a wider page context. Therefore, colour is inherited by default. 

It's recommended to use utilities for specific styling, just like [this variant](/pattern-library/pattern/labelled-icon/#styled-with-utilities).

```html
<p class="labelled-icon text-light text-step-2">…</p>
```