# Complete CSS Starter Files 

Welcome to Complete CSS! 

Once you have downloaded to starter files, open your terminal at the **root of the project** and run `npm install`. We recommend that you use the current [LTS version of Node JS](https://nodejs.org/en/download/package-manager) for this. At the time of writing, Node `v20.15.1` was used.

Once everything is installed, run `npm start` in your terminal. **This is the only command you need for the entire course**.

All the stub files are in place for you so sit back and enjoy the course 🙂

---

[Built with the CUBE CSS Boilerplate](https://piccalil.li/blog/a-css-project-boilerplate)
