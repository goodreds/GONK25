### Required patterns 

- [Corner](/pattern-library/pattern/corner)